package io.datajek.databaserelationships.onetomany.bi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseRelationshipsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseRelationshipsApplication.class, args);
	}

}